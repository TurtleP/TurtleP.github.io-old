function love.conf(t)
	t.console = false
	t.window.vsync = true
end