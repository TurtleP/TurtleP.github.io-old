playergravity = 400

_MAPNAMES =
{
	"Network of MyPC95",
	"Triple bass",
	"Climb or swim",
	"3x3cut3.msi",
	"Splish Splash",
	"Smile.jpg",
	"Where sleeping docs lie",
	"Leap of faith",
	"Danger zone",
	"Data trail",
	"Aqua jump",
	"The secret order",
	"Simplicity",
	"Encrypted passcodes"
}