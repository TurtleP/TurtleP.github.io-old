if [ -f "$HOME/.zshrc" ]; then # Running zsh
    echo 'source "\$HOME/.lovepotion/scripts/lovepotion"' | tee -a ~/.zshrc;
fi

if [ -f "$HOME/.bashrc" ]; then # Running bash
    echo 'source "\$HOME/.lovepotion/scripts/lovepotion"' | tee -a ~/.bashrc;
fi

echo ""
echo "Setup complete."
echo "If you need to build Love Potion games right away"
echo "run 'source ~/.lovepotion/scripts/lovepotion' in your terminal."
echo "Remember to download the latest elf files from GitHub"
echo "and place them inside ~/.lovepotion as '3ds.elf' and 'switch.elf'"